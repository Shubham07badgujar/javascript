import styles from './AppName.module.css'

function AppName() {
    return(
        <h1 styles={styles.todoHeading}>TODO APP</h1>
    );
}

export default AppName;